# Camp Bach — Game content

## Who knows who? · 15 profile questions

Each player answers these before entering the lobby. During the game the wording changes to ask about a random player.

1. **¿Qué color te representa más?** — Verde / Azul / Rojo / Rosa
2. **Tu comfort food de confianza es…** — Tacos / Sushi / Pasta / Pizza
3. **Si te ponen una bebida enfrente, ¿qué eliges?** — Vino / Tequila o mezcal / Spritz / Mocktail o refresco
4. **¿Qué postre gana siempre?** — Chocolate / Helado / Cheesecake / Churros
5. **Tu escape ideal se ve más como…** — Playa / Bosque + lago / Gran ciudad / Montaña
6. **Tu viernes perfecto es…** — Cena + vino / Bailar hasta tarde / Película + pijama / Roadtrip improvisado
7. **Cuando viajas eres más…** — Todo planeado / Improvisación total / Luxury + relax / Aventura primero
8. **¿Qué música pondrías primero?** — Pop / Reggaetón / Indie o rock / Electrónica
9. **¿Cuál es tu estación?** — Primavera / Verano / Otoño / Invierno
10. **¿Cómo funciona tu reloj interno?** — Early bird / Night owl / Depende del plan / Siempre con sueño
11. **Tu estilo se acerca más a…** — Clásico + neutro / Colorido + bold / Sporty + comfy / Trend + glam
12. **En el grupo normalmente eres…** — La organizadora / La fotógrafa / La que prende la fiesta / La mamá del grupo
13. **Domingo libre: ¿qué haces?** — Brunch / Naturaleza / Cama + series / Shopping
14. **Si hoy te caen $20,000 extra, ¿qué haces primero?** — Un viaje / Fashion o beauty / Casa o tech / Ahorrar o invertir
15. **¿Dónde vives actualmente?** — CDMX / Mexicali / Hermosillo / Guanajuato / San Francisco

### Game logic

- The app combines every player's 15 answers into a random pool of up to **40 possible facts**.
- Each match draws **5 questions** from that pool.
- Everyone has **10 seconds** to vote.
- If a question is about you, you sit that round out so there is no guaranteed correct vote.
- After each question it reveals the answer, shows how many people got it right, and updates the leaderboard.

## Yo nunca nunca · built-in deck

The page includes 50 built-in cards plus up to two optional anonymous suggestions from every player:

1. Yo nunca nunca he dicho “ya voy” sin haber salido de mi casa.
2. Yo nunca nunca me he quedado dormida en un Uber o en el coche de regreso.
3. Yo nunca nunca he comprado un vuelo o viaje casi por impulso.
4. Yo nunca nunca he stalkeado a alguien hasta años atrás en su perfil.
5. Yo nunca nunca he borrado un mensaje esperando que nadie alcanzara a verlo.
6. Yo nunca nunca le he escrito a alguien después de jurar que no lo iba a hacer.
7. Yo nunca nunca he fingido conocer una canción para seguir cantando.
8. Yo nunca nunca he pedido comida solo porque se veía bien en la foto.
9. Yo nunca nunca he llegado a una fiesta sin saber bien quién la organizaba.
10. Yo nunca nunca he inventado una excusa para cancelar planes.
11. Yo nunca nunca he llorado por una serie o película.
12. Yo nunca nunca he tenido un crush totalmente imposible.
13. Yo nunca nunca he besado a alguien y después actuado como si nada hubiera pasado.
14. Yo nunca nunca me he cambiado de outfit más de cuatro veces antes de salir.
15. Yo nunca nunca he dicho “ya estoy lista” cuando claramente no lo estaba.
16. Yo nunca nunca he perdido algo importante durante un viaje.
17. Yo nunca nunca he tenido una cita que salió terriblemente mal.
18. Yo nunca nunca he regresado con un ex o con un casi algo.
19. Yo nunca nunca he revisado el perfil de la nueva pareja de un ex.
20. Yo nunca nunca he guardado screenshots únicamente para mandarlos al grupo.
21. Yo nunca nunca he comprado algo porque TikTok o Instagram me convenció.
22. Yo nunca nunca he mandado un audio de más de cinco minutos.
23. Yo nunca nunca he fingido estar enferma para no salir.
24. Yo nunca nunca he hecho una nueva mejor amiga en el baño de un bar.
25. Yo nunca nunca he tomado una decisión importante en una noche de copas.
26. Yo nunca nunca he cantado karaoke sin saberme bien la letra.
27. Yo nunca nunca he terminado bailando arriba de una silla o mesa.
28. Yo nunca nunca he perdido mi celular en una fiesta.
29. Yo nunca nunca he viajado con una resaca terrible.
30. Yo nunca nunca he enviado un mensaje al chat equivocado.
31. Yo nunca nunca he llorado en un aeropuerto.
32. Yo nunca nunca he comprado algo caro y omitido cuánto me costó.
33. Yo nunca nunca he dicho “una y nos vamos” y terminado cerrando el lugar.
34. Yo nunca nunca he tenido un crush con alguien del trabajo o escuela.
35. Yo nunca nunca he fingido no ver a alguien en público.
36. Yo nunca nunca he investigado el signo zodiacal de alguien porque me interesaba.
37. Yo nunca nunca he pensado “me caso con esta persona” demasiado pronto.
38. Yo nunca nunca he subido algo a Close Friends y luego me he arrepentido.
39. Yo nunca nunca he borrado una foto porque ya no me gustó cómo se veía en mi feed.
40. Yo nunca nunca he fingido saber más de vino o cocteles de lo que realmente sé.
41. Yo nunca nunca he terminado en un lugar que no estaba para nada en el plan original.
42. Yo nunca nunca he nadado con ropa puesta.
43. Yo nunca nunca he usado lentes oscuros para esconder la noche anterior.
44. Yo nunca nunca he robado papas o comida del plato de alguien sin preguntar.
45. Yo nunca nunca he dicho “no tengo hambre” y luego he comido de todo.
46. Yo nunca nunca he hecho una escapada sin contarle a casi nadie.
47. Yo nunca nunca he tomado la misma foto muchísimas veces para subir una sola.
48. Yo nunca nunca he olvidado el nombre de alguien mientras hablaba con esa persona.
49. Yo nunca nunca me he peleado de verdad por un juego de mesa o cartas.
50. Yo nunca nunca he hecho algo únicamente porque sabía que sería una gran historia después.
