# Camp Bach · Andrea

Responsive parallax bachelorette-weekend site for Valle de Bravo, 8–11 October 2026.

## What is included

- Illustrated Valle de Bravo lake cover with layered parallax and embroidered kayak, pennant and rabbit patches.
- Vintage camp-club design in forest green, cream, burgundy and powder blue; interactive patches, countdown and expandable daily itinerary.
- Thursday arrival board + Friday/Saturday/Sunday itinerary.
- Google Maps and Apple Maps buttons for the two supplied addresses.
- Responsive mobile navigation.
- **Who knows who?** multiplayer trivia:
  - host creates a 5-digit room code;
  - every player answers 15 different profile questions;
  - optional 1–2 “Yo nunca nunca” submissions;
  - a pool of up to 40 player/fact questions is created;
  - each match draws 5 rounds;
  - 10-second timer;
  - the person a question is about sits that round out;
  - correct count + live leaderboard after every round.
- **Yo nunca nunca** animated card deck with 50 built-in cards plus player suggestions.

## Preview locally

Open `index.html` in a browser. Without Supabase keys, the game runs in **local demo mode**. Room codes work across tabs/windows in the same browser so you can test the flow.

For the easiest preview, you can also run a tiny local server from the project folder:

```bash
python3 -m http.server 8080
```

Then open `http://localhost:8080`.

## Make the game work across different phones

1. Create a free Supabase project.
2. In **Authentication > Sign In / Providers**, enable **Anonymous Sign-Ins**. Players receive a private session without an email or password.
3. Open **SQL Editor** and run `supabase-setup.sql`. It creates room-scoped access policies; only members read a room and only its host advances the game.
4. In Supabase, copy your **Project URL** and **anon/publishable key**.
5. Open `config.js` and paste them:

```js
window.CAMPBACH_CONFIG = {
  supabaseUrl: "https://YOUR-PROJECT.supabase.co",
  supabaseAnonKey: "YOUR-ANON-OR-PUBLISHABLE-KEY"
};
```

Never place a Supabase `service_role` secret in this site.

## Deploy to Netlify

Drag the entire `camp-bach-andrea` folder into Netlify Drop, or upload the folder to GitHub and connect the repository in Netlify. No build command is required because this is plain HTML/CSS/JS.

## Privacy note

The supplied itinerary includes private addresses. The page already has `noindex,nofollow`, but that does **not** make a public URL private. For a truly private invite, add authentication/password protection before sharing the final link.

## Main files

- `index.html` — page structure/content
- `styles.css` — design + responsive styles
- `app.js` — parallax, navigation, trivia and card game logic
- `config.js` — Supabase connection values
- `supabase-setup.sql` — database/realtime setup
- `assets/` — original lake illustration and embroidered patches optimized for web
- `GAME-CONTENT.md` — easy reference for the 15 profile questions and 50 “Yo nunca nunca” cards

## Mobile update

The layout supports small phones from 320 px, tablets, desktop, and landscape. The menu opens from the right, buttons have 44 px touch targets, form text stays at 16 px to avoid iPhone auto-zoom, and cards fit their containers.

`index-local.html` is a self-contained preview with the styles, scripts, and images embedded. Open it in a browser without moving any other files. The Google fonts are optional; system fonts are used offline. The online multiplayer configuration remains in `config.js` for the deployed site.
