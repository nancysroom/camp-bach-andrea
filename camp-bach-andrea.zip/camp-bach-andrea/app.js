(async () => {
  "use strict";

  const PROFILE_QUESTIONS = [
    { id: "color", profile: "¿Qué color te representa más?", game: (n) => `¿Qué color representa más a ${n}?`, options: ["Verde", "Azul", "Rojo", "Rosa"] },
    { id: "food", profile: "Tu comfort food de confianza es…", game: (n) => `¿Cuál es el comfort food de ${n}?`, options: ["Tacos", "Sushi", "Pasta", "Pizza"] },
    { id: "drink", profile: "Si te ponen una bebida enfrente, ¿qué eliges?", game: (n) => `¿Qué pediría primero ${n} para tomar?`, options: ["Vino", "Tequila / mezcal", "Spritz", "Mocktail / refresco"] },
    { id: "dessert", profile: "¿Qué postre gana siempre?", game: (n) => `¿Qué postre escogería ${n}?`, options: ["Chocolate", "Helado", "Cheesecake", "Churros"] },
    { id: "escape", profile: "Tu escape ideal se ve más como…", game: (n) => `¿Cuál sería el escape ideal de ${n}?`, options: ["Playa", "Bosque + lago", "Gran ciudad", "Montaña"] },
    { id: "friday", profile: "Tu viernes perfecto es…", game: (n) => `¿Cuál es el viernes perfecto de ${n}?`, options: ["Cena + vino", "Bailar hasta tarde", "Película + pijama", "Roadtrip improvisado"] },
    { id: "travel", profile: "Cuando viajas eres más…", game: (n) => `¿Cómo viaja ${n}?`, options: ["Todo planeado", "Improvisación total", "Luxury + relax", "Aventura primero"] },
    { id: "music", profile: "¿Qué música pondrías primero?", game: (n) => `¿Qué pondría primero ${n} en la playlist?`, options: ["Pop", "Reggaetón", "Indie / rock", "Electrónica"] },
    { id: "season", profile: "¿Cuál es tu estación?", game: (n) => `¿Qué estación prefiere ${n}?`, options: ["Primavera", "Verano", "Otoño", "Invierno"] },
    { id: "sleep", profile: "¿Cómo funciona tu reloj interno?", game: (n) => `¿Cuál describe mejor a ${n}?`, options: ["Early bird", "Night owl", "Depende del plan", "Siempre con sueño"] },
    { id: "style", profile: "Tu estilo se acerca más a…", game: (n) => `¿Cuál es más el estilo de ${n}?`, options: ["Clásico + neutro", "Colorido + bold", "Sporty + comfy", "Trend + glam"] },
    { id: "role", profile: "En el grupo normalmente eres…", game: (n) => `¿Qué rol suele tener ${n} en el grupo?`, options: ["La organizadora", "La fotógrafa", "La que prende la fiesta", "La mamá del grupo"] },
    { id: "sunday", profile: "Domingo libre: ¿qué haces?", game: (n) => `¿Qué plan elegiría ${n} un domingo libre?`, options: ["Brunch", "Naturaleza", "Cama + series", "Shopping"] },
    { id: "spend", profile: "Si hoy te caen $20,000 extra, ¿qué haces primero?", game: (n) => `¿En qué usaría primero ${n} $20,000 extra?`, options: ["Un viaje", "Fashion / beauty", "Casa / tech", "Ahorrar / invertir"] },
    { id: "city", profile: "¿Dónde vives actualmente?", game: (n) => `¿Dónde vive actualmente ${n}?`, options: ["CDMX", "Mexicali", "Hermosillo", "Guanajuato", "San Francisco"] }
  ];

  const NEVER_BUILT_INS = [
    "Yo nunca nunca he dicho “ya voy” sin haber salido de mi casa.",
    "Yo nunca nunca me he quedado dormida en un Uber o en el coche de regreso.",
    "Yo nunca nunca he comprado un vuelo o viaje casi por impulso.",
    "Yo nunca nunca he stalkeado a alguien hasta años atrás en su perfil.",
    "Yo nunca nunca he borrado un mensaje esperando que nadie alcanzara a verlo.",
    "Yo nunca nunca le he escrito a alguien después de jurar que no lo iba a hacer.",
    "Yo nunca nunca he fingido conocer una canción para seguir cantando.",
    "Yo nunca nunca he pedido comida solo porque se veía bien en la foto.",
    "Yo nunca nunca he llegado a una fiesta sin saber bien quién la organizaba.",
    "Yo nunca nunca he inventado una excusa para cancelar planes.",
    "Yo nunca nunca he llorado por una serie o película.",
    "Yo nunca nunca he tenido un crush totalmente imposible.",
    "Yo nunca nunca he besado a alguien y después actuado como si nada hubiera pasado.",
    "Yo nunca nunca me he cambiado de outfit más de cuatro veces antes de salir.",
    "Yo nunca nunca he dicho “ya estoy lista” cuando claramente no lo estaba.",
    "Yo nunca nunca he perdido algo importante durante un viaje.",
    "Yo nunca nunca he tenido una cita que salió terriblemente mal.",
    "Yo nunca nunca he regresado con un ex o con un casi algo.",
    "Yo nunca nunca he revisado el perfil de la nueva pareja de un ex.",
    "Yo nunca nunca he guardado screenshots únicamente para mandarlos al grupo.",
    "Yo nunca nunca he comprado algo porque TikTok o Instagram me convenció.",
    "Yo nunca nunca he mandado un audio de más de cinco minutos.",
    "Yo nunca nunca he fingido estar enferma para no salir.",
    "Yo nunca nunca he hecho una nueva mejor amiga en el baño de un bar.",
    "Yo nunca nunca he tomado una decisión importante en una noche de copas.",
    "Yo nunca nunca he cantado karaoke sin saberme bien la letra.",
    "Yo nunca nunca he terminado bailando arriba de una silla o mesa.",
    "Yo nunca nunca he perdido mi celular en una fiesta.",
    "Yo nunca nunca he viajado con una resaca terrible.",
    "Yo nunca nunca he enviado un mensaje al chat equivocado.",
    "Yo nunca nunca he llorado en un aeropuerto.",
    "Yo nunca nunca he comprado algo caro y omitido cuánto me costó.",
    "Yo nunca nunca he dicho “una y nos vamos” y terminado cerrando el lugar.",
    "Yo nunca nunca he tenido un crush con alguien del trabajo o escuela.",
    "Yo nunca nunca he fingido no ver a alguien en público.",
    "Yo nunca nunca he investigado el signo zodiacal de alguien porque me interesaba.",
    "Yo nunca nunca he pensado “me caso con esta persona” demasiado pronto.",
    "Yo nunca nunca he subido algo a Close Friends y luego me he arrepentido.",
    "Yo nunca nunca he borrado una foto porque ya no me gustó cómo se veía en mi feed.",
    "Yo nunca nunca he fingido saber más de vino o cocteles de lo que realmente sé.",
    "Yo nunca nunca he terminado en un lugar que no estaba para nada en el plan original.",
    "Yo nunca nunca he nadado con ropa puesta.",
    "Yo nunca nunca he usado lentes oscuros para esconder la noche anterior.",
    "Yo nunca nunca he robado papas o comida del plato de alguien sin preguntar.",
    "Yo nunca nunca he dicho “no tengo hambre” y luego he comido de todo.",
    "Yo nunca nunca he hecho una escapada sin contarle a casi nadie.",
    "Yo nunca nunca he tomado la misma foto muchísimas veces para subir una sola.",
    "Yo nunca nunca he olvidado el nombre de alguien mientras hablaba con esa persona.",
    "Yo nunca nunca me he peleado de verdad por un juego de mesa o cartas.",
    "Yo nunca nunca he hecho algo únicamente porque sabía que sería una gran historia después."
  ];

  const qs = (s, root = document) => root.querySelector(s);
  const qsa = (s, root = document) => [...root.querySelectorAll(s)];
  const esc = (v = "") => String(v).replace(/[&<>'"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;",'"':"&quot;"}[c]));
  const shuffle = (arr) => {
    const a = [...arr];
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  };
  const randomCode = () => String(Math.floor(10000 + Math.random() * 90000));
  const nowIso = () => new Date().toISOString();
  const uuid = () => typeof crypto !== "undefined" && crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`;

  // ---------- visual site interactions ----------
  const header = qs(".site-header");
  const heroImage = qs(".hero-image");
  const menuToggle = qs(".menu-toggle");
  const drawer = qs(".mobile-drawer");
  const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
  const mobileScreen = window.matchMedia("(max-width: 900px)");
  const onScroll = () => {
    header?.classList.toggle("scrolled", window.scrollY > 40);
    if (heroImage && !reducedMotion.matches) {
      const y = Math.min(window.scrollY, heroImage.parentElement.offsetHeight);
      heroImage.style.transform = `translate3d(0, ${y * .38}px, 0) scale(1.08)`;
    } else if (heroImage) {
      heroImage.style.transform = "none";
    }
  };
  let scrollPending = false;
  window.addEventListener("scroll", () => {
    if (scrollPending) return;
    scrollPending = true;
    requestAnimationFrame(() => { onScroll(); scrollPending = false; });
  }, { passive: true });
  window.addEventListener("resize", onScroll, { passive: true });
  reducedMotion.addEventListener("change", onScroll);
  onScroll();

  const setMenuOpen = (open, returnFocus = false) => {
    drawer.classList.toggle("open", open);
    document.body.classList.toggle("menu-open", open);
    menuToggle.setAttribute("aria-expanded", String(open));
    menuToggle.setAttribute("aria-label", open ? "Cerrar menú" : "Abrir menú");
    drawer.setAttribute("aria-hidden", String(!open));
    drawer.inert = !open;
    qs("main").inert = open;
    qs("footer").inert = open;
    if (returnFocus) menuToggle.focus();
  };
  menuToggle?.addEventListener("click", () => setMenuOpen(!drawer.classList.contains("open")));
  qsa(".mobile-drawer a").forEach(a => a.addEventListener("click", () => setMenuOpen(false)));
  mobileScreen.addEventListener("change", e => {
    if (!e.matches) setMenuOpen(false);
  });

  if ("IntersectionObserver" in window) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(e => {
        if (!e.isIntersecting) return;
        e.target.classList.add("visible");
        observer.unobserve(e.target);
      });
    }, { threshold: .08 });
    document.documentElement.classList.add("js");
    qsa(".reveal").forEach(el => observer.observe(el));
  }

  const selectGameTab = (btn) => {
    const key = btn.dataset.tab;
    qsa(".game-tab").forEach(b => {
      b.classList.toggle("active", b === btn);
      b.setAttribute("aria-selected", String(b === btn));
      b.tabIndex = b === btn ? 0 : -1;
    });
    qsa(".game-panel").forEach(p => {
      p.classList.toggle("active", p.dataset.panel === key);
      p.hidden = p.dataset.panel !== key;
    });
  };
  qsa(".game-tab").forEach(btn => {
    btn.addEventListener("click", () => selectGameTab(btn));
    btn.addEventListener("keydown", e => {
      if (!["ArrowLeft", "ArrowRight", "Home", "End"].includes(e.key)) return;
      e.preventDefault();
      const tabs = qsa(".game-tab");
      const index = tabs.indexOf(btn);
      const next = e.key === "Home" ? 0 : e.key === "End" ? tabs.length - 1 : (index + (e.key === "ArrowRight" ? 1 : -1) + tabs.length) % tabs.length;
      selectGameTab(tabs[next]);
      tabs[next].focus();
    });
  });

  // ---------- modal ----------
  const modalShell = qs("#modal-shell");
  const modalContent = qs("#modal-content");
  let modalTrigger = null;
  const openModal = (html) => {
    setMenuOpen(false);
    modalTrigger = document.activeElement;
    modalContent.innerHTML = html;
    qs("h3", modalContent)?.setAttribute("id", "modal-title");
    modalShell.classList.add("open");
    modalShell.setAttribute("aria-hidden", "false");
    document.body.classList.add("modal-open");
    qs("main").inert = true;
    qs("footer").inert = true;
    header.inert = true;
    qs("input", modalContent)?.focus({ preventScroll: true });
  };
  const closeModal = () => {
    if (!modalShell.classList.contains("open")) return;
    modalShell.classList.remove("open");
    modalShell.setAttribute("aria-hidden", "true");
    document.body.classList.remove("modal-open");
    qs("main").inert = false;
    qs("footer").inert = false;
    header.inert = false;
    modalTrigger?.focus({ preventScroll: true });
  };
  qsa("[data-close-modal]").forEach(el => el.addEventListener("click", closeModal));
  document.addEventListener("keydown", e => {
    if (e.key === "Escape") {
      if (modalShell.classList.contains("open")) closeModal();
      else if (drawer.classList.contains("open")) setMenuOpen(false, true);
    }
    if (e.key !== "Tab") return;
    const activeRoot = modalShell.classList.contains("open") ? modalShell : drawer.classList.contains("open") ? drawer : null;
    if (!activeRoot) return;
    const controls = qsa('a[href], button:not(:disabled), input, textarea, [tabindex="0"]', activeRoot).filter(el => !el.hidden);
    if (activeRoot === drawer) controls.unshift(menuToggle);
    const first = controls[0], last = controls[controls.length - 1];
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last?.focus(); }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first?.focus(); }
  });

  // ---------- backend ----------
  const config = window.CAMPBACH_CONFIG || {};
  if (config.supabaseUrl && config.supabaseAnonKey && !window.supabase?.createClient) {
    try {
      await new Promise((resolve, reject) => {
        const script = document.createElement("script");
        const timeout = setTimeout(() => reject(new Error("Tiempo de conexión agotado")), 8000);
        script.src = "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2";
        script.onload = () => { clearTimeout(timeout); resolve(); };
        script.onerror = () => { clearTimeout(timeout); reject(new Error("Sin conexión")); };
        document.head.appendChild(script);
      });
    } catch {
      const note = document.createElement("p");
      note.className = "error-note";
      note.setAttribute("role", "status");
      note.textContent = "No pudimos conectar la trivia. Revisa tu conexión y vuelve a cargar la página.";
      qs(".game-intro-grid").appendChild(note);
      qsa("#create-room-btn, #join-room-btn").forEach(btn => { btn.disabled = true; });
    }
  }
  const hasSupabase = Boolean(config.supabaseUrl && config.supabaseAnonKey && window.supabase?.createClient);
  const sb = hasSupabase ? window.supabase.createClient(config.supabaseUrl, config.supabaseAnonKey) : null;
  const LOCAL_LISTENERS = new Map();

  const localKey = code => `campbach_room_${String(code).toUpperCase()}`;
  const readLocal = code => {
    let raw;
    try { raw = localStorage.getItem(localKey(code)); }
    catch { throw new Error("Abre la página en Safari o Chrome para jugar; esta vista previa bloquea el almacenamiento."); }
    return raw ? JSON.parse(raw) : null;
  };
  const writeLocal = room => {
    try { localStorage.setItem(localKey(room.code), JSON.stringify(room)); }
    catch { throw new Error("No se pudo guardar el juego. Abre la página en Safari o Chrome y permite el almacenamiento."); }
    (LOCAL_LISTENERS.get(room.code) || []).forEach(fn => fn());
  };
  window.addEventListener("storage", e => {
    if (!e.key?.startsWith("campbach_room_")) return;
    const code = e.key.replace("campbach_room_", "");
    (LOCAL_LISTENERS.get(code) || []).forEach(fn => fn());
  });

  const localBackend = {
    mode: "demo",
    async createRoom(name) {
      let code = randomCode();
      while (readLocal(code)) code = randomCode();
      const player = { id: uuid(), room_id: code, name, answers: {}, suggestions: [], ready: false, score: 0, created_at: nowIso() };
      const room = { id: code, code, host_player_id: player.id, status: "lobby", game_state: { phase: "lobby" }, players: [player], votes: [], created_at: nowIso() };
      writeLocal(room);
      return { room, player };
    },
    async joinRoom(code, name) {
      const room = readLocal(code);
      if (!room) throw new Error("No encontré ese código en este navegador.");
      if (room.status !== "lobby") throw new Error("La partida ya empezó.");
      if (room.players.some(p => p.name.toLowerCase() === name.toLowerCase())) throw new Error("Ese nombre ya está dentro del juego.");
      const player = { id: uuid(), room_id: room.id, name, answers: {}, suggestions: [], ready: false, score: 0, created_at: nowIso() };
      room.players.push(player); writeLocal(room);
      return { room, player };
    },
    async getSnapshot(code) {
      const r = readLocal(code);
      if (!r) throw new Error("Room no encontrado.");
      return { room: r, players: r.players || [], votes: r.votes || [] };
    },
    async updatePlayer(player) {
      const room = readLocal(player.room_id);
      const i = room.players.findIndex(p => p.id === player.id);
      if (i >= 0) room.players[i] = { ...room.players[i], ...player };
      writeLocal(room);
    },
    async updateRoom(roomId, patch) {
      const room = readLocal(roomId);
      Object.assign(room, patch);
      writeLocal(room);
    },
    async submitVote(vote) {
      const room = readLocal(vote.room_id);
      const idx = room.votes.findIndex(v => v.round_no === vote.round_no && v.player_id === vote.player_id);
      if (idx >= 0) room.votes[idx] = vote; else room.votes.push(vote);
      writeLocal(room);
    },
    subscribe(code, fn) {
      if (!LOCAL_LISTENERS.has(code)) LOCAL_LISTENERS.set(code, []);
      LOCAL_LISTENERS.get(code).push(fn);
      return () => LOCAL_LISTENERS.set(code, (LOCAL_LISTENERS.get(code) || []).filter(x => x !== fn));
    }
  };

  const supaBackend = {
    mode: "supabase",
    async ensureSession() {
      const { data, error } = await sb.auth.getSession();
      if (error) throw error;
      if (!data.session) {
        const result = await sb.auth.signInAnonymously();
        if (result.error) throw new Error("Falta activar Anonymous Sign-Ins en Supabase o no se pudo conectar. Intenta de nuevo.");
      }
    },
    async enter(name, code = null) {
      await this.ensureSession();
      const { data, error } = await sb.rpc("camp_enter_room", { player_name: name, room_code: code });
      if (error) throw new Error(error.code === "PGRST202" ? "Falta ejecutar el archivo de configuración en Supabase." : error.message);
      return data;
    },
    async createRoom(name) { return this.enter(name); },
    async joinRoom(code, name) { return this.enter(name, String(code)); },
    async getSnapshot(code) {
      const r = await sb.from("rooms").select("*").eq("code", String(code)).single();
      if (r.error) throw r.error;
      const [p, v] = await Promise.all([
        sb.from("players").select("*").eq("room_id", r.data.id).order("created_at"),
        sb.from("votes").select("*").eq("room_id", r.data.id)
      ]);
      if (p.error) throw p.error;
      if (v.error) throw v.error;
      return { room: r.data, players: p.data || [], votes: v.data || [] };
    },
    async updatePlayer(player) {
      const { id, name, answers, suggestions, ready, score } = player;
      const r = await sb.from("players").update({ name, answers, suggestions, ready, score }).eq("id", id);
      if (r.error) throw r.error;
    },
    async updateRoom(roomId, patch) {
      const r = await sb.from("rooms").update(patch).eq("id", roomId);
      if (r.error) throw r.error;
    },
    async submitVote(vote) {
      const r = await sb.from("votes").upsert(vote, { onConflict: "room_id,round_no,player_id" });
      if (r.error) throw r.error;
    },
    subscribe(code, fn) {
      let roomId = null;
      let channel = null;
      let stopped = false;
      let timeout;
      const refresh = () => { clearTimeout(timeout); timeout = setTimeout(() => !stopped && fn(), 90); };
      (async () => {
        const snap = await this.getSnapshot(code);
        roomId = snap.room.id;
        if (stopped) return;
        channel = sb.channel(`campbach-${roomId}`)
          .on("postgres_changes", { event: "*", schema: "public", table: "rooms", filter: `id=eq.${roomId}` }, refresh)
          .on("postgres_changes", { event: "*", schema: "public", table: "players", filter: `room_id=eq.${roomId}` }, refresh)
          .on("postgres_changes", { event: "*", schema: "public", table: "votes", filter: `room_id=eq.${roomId}` }, refresh)
          .subscribe();
      })().catch(err => console.error("Realtime:", err));
      const poll = setInterval(() => !stopped && fn(), 2500);
      return () => { stopped = true; clearInterval(poll); clearTimeout(timeout); if (channel) sb.removeChannel(channel); };
    }
  };

  const backend = hasSupabase ? supaBackend : localBackend;
  const connectionNote = document.createElement("p");
  connectionNote.className = "game-connection-note";
  connectionNote.setAttribute("role", "status");
  connectionNote.textContent = hasSupabase
    ? "Conexión online configurada. Comparte el código con tus amigas."
    : "Trivia en modo de prueba: los códigos solo funcionan en este navegador, no entre celulares. Yo nunca nunca sí está listo para jugar juntas desde una pantalla.";
  qs(".game-intro-grid").after(connectionNote);

  // ---------- trivia app state ----------
  const triviaApp = qs("#trivia-app");
  const game = {
    room: null,
    players: [],
    votes: [],
    meId: null,
    unsubscribe: null,
    timer: null,
    profileStep: 0,
    draftAnswers: {},
    draftSuggestions: ["", ""],
    refreshBusy: false,
    sessionVersion: 0
  };

  const me = () => game.players.find(p => p.id === game.meId);
  const isHost = () => game.room?.host_player_id === game.meId;
  const roomState = () => game.room?.game_state || { phase: "lobby" };

  async function refreshSnapshot() {
    if (!game.room || game.refreshBusy) return;
    game.refreshBusy = true;
    const version = game.sessionVersion;
    try {
      const snap = await backend.getSnapshot(game.room.code);
      if (version !== game.sessionVersion || !game.room) return;
      game.room = snap.room;
      game.players = snap.players;
      game.votes = snap.votes;
      renderTrivia();
      rebuildNeverDeck(false);
      maybeAutoFinalize();
    } catch (err) {
      console.error(err);
    } finally { game.refreshBusy = false; }
  }

  async function enterRoom(room, player) {
    if (game.unsubscribe) game.unsubscribe();
    game.sessionVersion++;
    game.room = room; game.meId = player.id;
    game.profileStep = 0;
    game.draftAnswers = { ...(player.answers || {}) };
    game.draftSuggestions = [...(player.suggestions || []), "", ""].slice(0, 2);
    try { sessionStorage.setItem("campbach_session", JSON.stringify({ code: room.code, playerId: player.id })); } catch { /* Continue without session persistence. */ }
    game.unsubscribe = backend.subscribe(room.code, refreshSnapshot);
    await refreshSnapshot();
  }

  function renderTrivia() {
    clearInterval(game.timer); game.timer = null;
    if (!game.room) { triviaApp.innerHTML = ""; return; }
    const current = me();
    if (!current) {
      triviaApp.innerHTML = `<p class="error-note">Tu sesión ya no está dentro de este room. Vuelve a entrar con el código.</p>`;
      return;
    }
    if (!current.ready && game.room.status === "lobby") return renderProfileWizard(current);
    if (game.room.status === "lobby") return renderLobby();
    if (game.room.status === "playing") {
      if (roomState().phase === "reveal") return renderReveal();
      return renderQuestion();
    }
    if (game.room.status === "finished") return renderFinished();
  }

  function renderProfileWizard(current) {
    if (!Object.keys(game.draftAnswers).length && current.answers) game.draftAnswers = { ...current.answers };
    const total = PROFILE_QUESTIONS.length;
    if (game.profileStep < total) {
      const q = PROFILE_QUESTIONS[game.profileStep];
      const selected = game.draftAnswers[q.id];
      triviaApp.innerHTML = `
        <div class="profile-wizard">
          <div class="room-topbar">
            <span class="room-status">Room ${esc(game.room.code)} · ${backend.mode === "demo" ? "DEMO LOCAL" : "LIVE"}</span>
            <span class="room-status">Hola, ${esc(current.name)}</span>
          </div>
          <div class="profile-progress"><span>${String(game.profileStep + 1).padStart(2,"0")} / ${total}</span><div class="progress-line"><i style="width:${((game.profileStep + 1)/total)*100}%"></i></div></div>
          <div class="profile-question">
            <h4>${esc(q.profile)}</h4>
            <div class="answer-grid">
              ${q.options.map(o => `<button class="answer-option ${selected === o ? "selected" : ""}" data-answer="${esc(o)}" aria-pressed="${selected === o}">${esc(o)}</button>`).join("")}
            </div>
          </div>
          <div class="wizard-footer">
            <button class="ghost-btn" id="profile-back" ${game.profileStep === 0 ? "disabled" : ""}>Atrás</button>
            <button class="primary-btn" id="profile-next" ${selected ? "" : "disabled"}>Siguiente</button>
          </div>
        </div>`;
      qsa("[data-answer]", triviaApp).forEach(btn => btn.addEventListener("click", () => {
        game.draftAnswers[q.id] = btn.dataset.answer;
        qsa("[data-answer]", triviaApp).forEach(b => {
          b.classList.toggle("selected", b === btn);
          b.setAttribute("aria-pressed", String(b === btn));
        });
        qs("#profile-next", triviaApp).disabled = false;
      }));
      qs("#profile-back", triviaApp)?.addEventListener("click", () => { game.profileStep--; renderTrivia(); });
      qs("#profile-next", triviaApp)?.addEventListener("click", () => { game.profileStep++; renderTrivia(); });
      return;
    }

    triviaApp.innerHTML = `
      <div class="profile-wizard">
        <div class="profile-progress"><span>LAST STEP</span><div class="progress-line"><i style="width:100%"></i></div></div>
        <div class="profile-question">
          <h4>¿Quieres agregar 1 o 2 cartas de “Yo nunca nunca”?</h4>
          <p style="color:rgba(255,255,255,.65);line-height:1.7">Es opcional. No pongas tu nombre; las sugerencias se mezclan anónimamente con la baraja.</p>
          <div class="suggestion-fields">
            <textarea maxlength="180" id="sugg-1" aria-label="Primera carta sugerida (opcional)" placeholder="Yo nunca nunca…">${esc(game.draftSuggestions[0])}</textarea>
            <textarea maxlength="180" id="sugg-2" aria-label="Segunda carta sugerida (opcional)" placeholder="Yo nunca nunca…">${esc(game.draftSuggestions[1])}</textarea>
          </div>
        </div>
        <div class="wizard-footer">
          <button class="ghost-btn" id="profile-back">Atrás</button>
          <button class="primary-btn" id="finish-profile">Entrar al lobby</button>
        </div>
      </div>`;
    qs("#profile-back", triviaApp).addEventListener("click", () => { game.profileStep = total - 1; renderTrivia(); });
    qs("#finish-profile", triviaApp).addEventListener("click", async () => {
      const a = qs("#sugg-1", triviaApp).value.trim();
      const b = qs("#sugg-2", triviaApp).value.trim();
      game.draftSuggestions = [a,b];
      const player = { ...current, answers: game.draftAnswers, suggestions: [a,b].filter(Boolean), ready: true };
      await backend.updatePlayer(player);
      await refreshSnapshot();
    });
  }

  function renderLobby() {
    const ready = game.players.filter(p => p.ready);
    triviaApp.innerHTML = `
      <div class="room-shell">
        <div class="room-topbar">
          <div class="room-code"><span class="room-status">CODE</span><strong>${esc(game.room.code)}</strong><button class="ghost-btn" id="copy-code">Copiar</button></div>
          <div class="room-status">${backend.mode === "demo" ? "Demo local · abre otra pestaña para probar" : "Live multiplayer"}</div>
        </div>
        <div>
          <span class="label light-label">LOBBY · ${ready.length} READY</span>
          <div class="players-grid" style="margin-top:14px">
            ${game.players.map(p => `<div class="player-pill"><span>${esc(p.name)}${p.id === game.room.host_player_id ? " · host" : ""}</span><i class="ready-dot ${p.ready ? "on" : ""}"></i></div>`).join("")}
          </div>
        </div>
        ${ready.length < 2 ? `<p class="room-status">Se necesitan al menos 2 jugadoras con su perfil completo para empezar.</p>` : ""}
        ${isHost() ? `<div class="host-controls"><button class="primary-btn" id="start-game" ${ready.length < 2 ? "disabled" : ""}>Empezar 5 rondas</button></div>` : `<p class="room-status">Esperando a que la host inicie la partida…</p>`}
      </div>`;
    qs("#copy-code", triviaApp)?.addEventListener("click", async e => {
      try { await navigator.clipboard.writeText(game.room.code); e.currentTarget.textContent = "Copiado"; } catch { /* noop */ }
    });
    qs("#start-game", triviaApp)?.addEventListener("click", startGame);
  }

  function buildPool(players) {
    const all = [];
    players.forEach(p => PROFILE_QUESTIONS.forEach(q => {
      if (p.answers?.[q.id]) all.push({ subjectId: p.id, qid: q.id });
    }));
    return shuffle(all).slice(0, Math.min(40, all.length));
  }

  function chooseRounds(pool, players) {
    const chosen = [];
    let candidates = [...pool];
    const preferredSubjects = shuffle(players.map(p => p.id));
    for (let i = 0; i < 5 && candidates.length; i++) {
      const target = preferredSubjects[i % preferredSubjects.length];
      let idx = candidates.findIndex(c => c.subjectId === target && !chosen.some(x => x.subjectId === c.subjectId && x.qid === c.qid));
      if (idx < 0) idx = 0;
      const item = candidates.splice(idx,1)[0];
      const subject = players.find(p => p.id === item.subjectId);
      const q = PROFILE_QUESTIONS.find(x => x.id === item.qid);
      const correct = subject.answers[item.qid];
      const wrong = shuffle(q.options.filter(o => o !== correct)).slice(0,3);
      chosen.push({ ...item, choices: shuffle([correct, ...wrong]) });
    }
    return chosen;
  }

  async function startGame() {
    const ready = game.players.filter(p => p.ready);
    if (ready.length < 2) return;
    const pool = buildPool(ready);
    const rounds = chooseRounds(pool, ready);
    const start = Date.now();
    for (const p of ready) { if (p.score !== 0) await backend.updatePlayer({ ...p, score: 0 }); }
    await backend.updateRoom(game.room.id, {
      status: "playing",
      game_state: {
        phase: "question",
        pool,
        rounds,
        roundIndex: 0,
        roundStartedAt: new Date(start).toISOString(),
        roundEndsAt: new Date(start + 10000).toISOString()
      }
    });
    await refreshSnapshot();
  }

  function currentRound() {
    const s = roomState();
    return s.rounds?.[s.roundIndex] || null;
  }
  function roundVotes() {
    const s = roomState();
    return game.votes.filter(v => Number(v.round_no) === Number(s.roundIndex));
  }

  function renderQuestion() {
    const s = roomState();
    const r = currentRound();
    if (!r) return;
    const subject = game.players.find(p => p.id === r.subjectId);
    const q = PROFILE_QUESTIONS.find(x => x.id === r.qid);
    const current = me();
    const myVote = roundVotes().find(v => v.player_id === current.id);
    const spectator = current.id === subject.id;
    triviaApp.innerHTML = `
      <div class="question-stage">
        <div class="timer-ring" id="timer-ring">10</div>
        <div class="round-label">ROUND ${s.roundIndex + 1} / ${s.rounds.length}</div>
        <h4>${esc(q.game(subject.name))}</h4>
        ${spectator ? `<div class="subject-note">Esta es sobre ti, ${esc(current.name)}. Esta ronda solo miras qué contesta el grupo 👀</div>` : `
          <div class="game-choice-grid">
            ${r.choices.map(c => `<button class="game-choice ${myVote ? "locked" : ""} ${myVote?.answer === c ? "chosen" : ""}" data-choice="${esc(c)}">${esc(c)}</button>`).join("")}
          </div>
          <p class="room-status" style="margin-top:16px">${myVote ? "Respuesta enviada" : "Elige antes de que llegue a 0"}</p>`}
      </div>`;
    if (!spectator && !myVote) {
      qsa("[data-choice]", triviaApp).forEach(btn => btn.addEventListener("click", async () => {
        qsa("[data-choice]", triviaApp).forEach(b => b.classList.add("locked"));
        btn.classList.add("chosen");
        const responseMs = Math.max(0, Date.now() - new Date(s.roundStartedAt).getTime());
        await backend.submitVote({ id: uuid(), room_id: game.room.id, round_no: s.roundIndex, player_id: current.id, answer: btn.dataset.choice, response_ms: responseMs, created_at: nowIso() });
        await refreshSnapshot();
      }));
    }
    const tick = () => {
      const left = Math.max(0, Math.ceil((new Date(roomState().roundEndsAt).getTime() - Date.now()) / 1000));
      const ring = qs("#timer-ring", triviaApp);
      if (ring) ring.textContent = String(left);
      if (left <= 0) { clearInterval(game.timer); game.timer = null; if (isHost()) finalizeRound(); }
    };
    tick(); game.timer = setInterval(tick, 250);
  }

  async function maybeAutoFinalize() {
    if (!isHost() || game.room?.status !== "playing" || roomState().phase !== "question") return;
    const r = currentRound();
    if (!r) return;
    const eligible = game.players.filter(p => p.ready && p.id !== r.subjectId);
    const votes = roundVotes().filter(v => eligible.some(p => p.id === v.player_id));
    if (eligible.length && votes.length >= eligible.length) await finalizeRound();
  }

  let finalizeLock = false;
  async function finalizeRound() {
    if (finalizeLock || !isHost() || roomState().phase !== "question") return;
    finalizeLock = true;
    try {
      const s = roomState();
      const r = currentRound();
      const subject = game.players.find(p => p.id === r.subjectId);
      const correct = subject.answers[r.qid];
      const votes = roundVotes().filter(v => v.player_id !== subject.id);
      let correctCount = 0;
      for (const v of votes) {
        if (v.answer === correct) {
          correctCount++;
          const p = game.players.find(x => x.id === v.player_id);
          if (p) {
            const timeBonus = Math.max(0, 500 - Math.floor((Number(v.response_ms || 10000)) / 20));
            await backend.updatePlayer({ ...p, score: Number(p.score || 0) + 1000 + timeBonus });
          }
        }
      }
      await backend.updateRoom(game.room.id, {
        game_state: { ...s, phase: "reveal", revealStats: { correctCount, total: game.players.filter(p => p.ready && p.id !== subject.id).length, correct } }
      });
      await refreshSnapshot();
    } finally { finalizeLock = false; }
  }

  function renderReveal() {
    const s = roomState();
    const r = currentRound();
    const subject = game.players.find(p => p.id === r.subjectId);
    const q = PROFILE_QUESTIONS.find(x => x.id === r.qid);
    const stats = s.revealStats || { correctCount: 0, total: 0, correct: subject.answers[r.qid] };
    const leaders = [...game.players].filter(p => p.ready).sort((a,b) => Number(b.score||0) - Number(a.score||0));
    triviaApp.innerHTML = `
      <div class="question-stage">
        <div class="round-label">THE ANSWER</div>
        <h4>${esc(q.game(subject.name))}</h4>
        <div class="reveal-answer">${esc(stats.correct)}</div>
        <div class="reveal-stat">${stats.correctCount} de ${stats.total} la conocían ✦</div>
        <div class="leaderboard">
          ${leaders.map((p,i) => `<div class="leader-row"><strong>${String(i+1).padStart(2,"0")}</strong><span>${esc(p.name)}</span><em>${Number(p.score||0).toLocaleString()} PTS</em></div>`).join("")}
        </div>
        ${isHost() ? `<div class="host-controls" style="margin-top:26px"><button class="primary-btn" id="next-round">${s.roundIndex + 1 >= s.rounds.length ? "Ver resultados" : "Siguiente pregunta"}</button></div>` : `<p class="room-status" style="margin-top:24px">Esperando a la host…</p>`}
      </div>`;
    qs("#next-round", triviaApp)?.addEventListener("click", nextRound);
  }

  async function nextRound() {
    const s = roomState();
    if (s.roundIndex + 1 >= s.rounds.length) {
      await backend.updateRoom(game.room.id, { status: "finished", game_state: { ...s, phase: "finished" } });
    } else {
      const start = Date.now();
      await backend.updateRoom(game.room.id, { game_state: { ...s, phase: "question", roundIndex: s.roundIndex + 1, roundStartedAt: new Date(start).toISOString(), roundEndsAt: new Date(start+10000).toISOString(), revealStats: null } });
    }
    await refreshSnapshot();
  }

  function closeResults() {
    game.sessionVersion++;
    game.unsubscribe?.();
    game.unsubscribe = null;
    clearInterval(game.timer);
    game.timer = null;
    game.room = null;
    game.meId = null;
    game.players = [];
    game.votes = [];
    game.draftAnswers = {};
    game.draftSuggestions = ["", ""];
    try { sessionStorage.removeItem("campbach_session"); } catch {}
    triviaApp.innerHTML = "";
    rebuildNeverDeck(false);
    qs("#create-room-btn")?.focus({ preventScroll: true });
  }

  function renderFinished() {
    const leaders = [...game.players].filter(p => p.ready).sort((a,b) => Number(b.score||0) - Number(a.score||0));
    triviaApp.innerHTML = `
      <div class="question-stage">
        <div class="round-label">FINAL SCORE</div>
        <h4>${leaders[0] ? `${esc(leaders[0].name)} knows the group best.` : "Game over"}</h4>
        <div class="leaderboard">
          ${leaders.map((p,i) => `<div class="leader-row"><strong>${String(i+1).padStart(2,"0")}</strong><span>${esc(p.name)}</span><em>${Number(p.score||0).toLocaleString()} PTS</em></div>`).join("")}
        </div>
        <div class="host-controls" style="margin-top:26px">
          <button class="primary-btn" id="close-results">Cerrar resultados</button>
          ${isHost() ? `<button class="primary-btn" id="play-again">Otra partida</button>` : ""}
        </div>
      </div>`;
    qs("#close-results", triviaApp)?.addEventListener("click", closeResults);
    qs("#play-again", triviaApp)?.addEventListener("click", async () => {
      await backend.updateRoom(game.room.id, { status: "lobby", game_state: { phase: "lobby" } });
      await refreshSnapshot();
    });
  }

  // ---------- create / join ----------
  qs("#create-room-btn")?.addEventListener("click", () => {
    openModal(`
      <h3>Create a game</h3>
      <p>Te damos un código para compartir. Todas contestan su perfil antes de jugar.</p>
      ${backend.mode === "demo" ? `<p class="error-note">Modo de prueba: el código funciona entre pestañas de este navegador. Para jugar desde distintos celulares, falta activar la conexión.</p>` : ""}
      <form id="create-room-form">
        <div class="form-row"><label for="host-name">Tu nombre</label><input id="host-name" maxlength="28" autocomplete="given-name" required placeholder="Nancy" /></div>
        <div class="modal-actions"><button type="button" class="modal-secondary" data-close-now>Cancelar</button><button class="modal-primary" type="submit">Crear código</button></div>
      </form>`);
    qs("[data-close-now]", modalContent).addEventListener("click", closeModal);
    qs("#create-room-form", modalContent).addEventListener("submit", async e => {
      e.preventDefault();
      const name = qs("#host-name", modalContent).value.trim();
      if (!name) return;
      try { const { room, player } = await backend.createRoom(name); closeModal(); await enterRoom(room, player); qs("#games")?.scrollIntoView({behavior:"smooth"}); }
      catch (err) { showModalError(err.message); }
    });
  });

  qs("#join-room-btn")?.addEventListener("click", () => {
    openModal(`
      <h3>Join the room</h3>
      <p>${backend.mode === "demo" ? "Este modo solo encuentra códigos creados en otra pestaña de este mismo navegador. La conexión entre celulares aún no está activada." : "Escribe el código que aparece en la pantalla de la host."}</p>
      <form id="join-room-form">
        <div class="form-row"><label for="join-code">Código</label><input id="join-code" inputmode="numeric" pattern="[0-9]{5}" maxlength="5" autocomplete="off" required placeholder="48216" /></div>
        <div class="form-row"><label for="join-name">Tu nombre</label><input id="join-name" maxlength="28" autocomplete="given-name" required placeholder="Andrea" /></div>
        <div class="modal-actions"><button type="button" class="modal-secondary" data-close-now>Cancelar</button><button class="modal-primary" type="submit">Entrar</button></div>
      </form>`);
    qs("[data-close-now]", modalContent).addEventListener("click", closeModal);
    qs("#join-room-form", modalContent).addEventListener("submit", async e => {
      e.preventDefault();
      const code = qs("#join-code", modalContent).value.trim();
      const name = qs("#join-name", modalContent).value.trim();
      try { const { room, player } = await backend.joinRoom(code, name); closeModal(); await enterRoom(room, player); }
      catch (err) { showModalError(err.message); }
    });
  });

  function showModalError(message) {
    let note = qs(".dynamic-error", modalContent);
    if (!note) { note = document.createElement("p"); note.className = "error-note dynamic-error"; modalContent.appendChild(note); }
    note.textContent = message;
  }

  // restore session
  (async () => {
    try {
      const session = JSON.parse(sessionStorage.getItem("campbach_session") || "null");
      if (!session?.code || !session?.playerId) return;
      const snap = await backend.getSnapshot(session.code);
      if (snap.room.status === "finished") {
        sessionStorage.removeItem("campbach_session");
        return;
      }
      const player = snap.players.find(p => p.id === session.playerId);
      if (player) await enterRoom(snap.room, player);
    } catch { /* stale session */ }
  })();

  // ---------- Yo Nunca Nunca deck ----------
  let neverDeck = [...NEVER_BUILT_INS];
  let neverIndex = 0;
  const neverCard = qs("#never-card");
  const neverText = qs("#never-text");
  const neverCount = qs("#never-count");

  function rebuildNeverDeck(shuffleIt = false) {
    const suggestions = game.players.flatMap(p => (p.suggestions || []).filter(Boolean)).map(t => /^yo nunca nunca/i.test(t) ? t : `Yo nunca nunca ${t}`);
    neverDeck = [...NEVER_BUILT_INS, ...suggestions];
    if (shuffleIt) neverDeck = shuffle(neverDeck);
    neverIndex = 0;
    showNeverCard(false);
  }
  function showNeverCard(animate = true) {
    if (!neverDeck.length) return;
    const update = () => {
      neverText.textContent = neverDeck[neverIndex];
      neverCount.textContent = `${String(neverIndex + 1).padStart(2,"0")} / ${neverDeck.length}`;
      neverCard.classList.remove("swap-out");
      neverCard.classList.add("swap-in");
      setTimeout(() => neverCard.classList.remove("swap-in"), 420);
    };
    if (!animate) return update();
    neverCard.classList.add("swap-out");
    setTimeout(update, 220);
  }
  qs("#next-never")?.addEventListener("click", () => { neverIndex = (neverIndex + 1) % neverDeck.length; showNeverCard(true); });
  qs("#shuffle-never")?.addEventListener("click", () => rebuildNeverDeck(true));
  rebuildNeverDeck(false);

  document.addEventListener("visibilitychange", () => { if (!document.hidden && game.players.length) rebuildNeverDeck(false); });
})();
