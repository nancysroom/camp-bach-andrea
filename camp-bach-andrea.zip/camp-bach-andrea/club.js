(() => {
  const reduce = matchMedia('(prefers-reduced-motion: reduce)');
  const layers = [...document.querySelectorAll('[data-parallax]')];
  let queued = false;
  function move() {
    const travel = Math.min(scrollY, innerHeight * 1.2);
    layers.forEach(el => el.style.setProperty('--parallax-y', `${reduce.matches ? 0 : travel * Number(el.dataset.parallax)}px`));
    queued = false;
  }
  addEventListener('scroll', () => { if (!queued) { queued = true; requestAnimationFrame(move); } }, {passive:true});
  reduce.addEventListener('change', move); move();
  document.querySelectorAll('[data-burst]').forEach(button => button.addEventListener('click', () => {
    button.animate([{scale:'1'},{scale:'1.09',rotate:'4deg'},{scale:'1'}],{duration:reduce.matches?1:340,easing:'ease-out'});
    if (reduce.matches) return;
    const rect = button.getBoundingClientRect();
    const colors = ['#8b2235', '#b8d6ee', '#f6eacb', '#315744', '#d2a458'];
    for (let i=0;i<32;i++) {
      const particle = document.createElement('span');
      particle.className = 'club-confetti';
      particle.setAttribute('aria-hidden', 'true');
      particle.style.backgroundColor = colors[i % colors.length];
      particle.style.borderRadius = i % 3 === 0 ? '50%' : '2px';
      particle.style.left = `${rect.left + rect.width/2}px`;
      particle.style.top = `${rect.top + rect.height/2}px`;
      document.body.appendChild(particle);
      const angle = Math.PI*2*i/32;
      const distance = 80 + Math.random() * 110;
      const flight = particle.animate([
        {transform:'translate(-50%,-50%) scale(.4)',opacity:1},
        {transform:`translate(calc(-50% + ${Math.cos(angle)*distance}px),calc(-50% + ${Math.sin(angle)*distance-70}px)) rotate(${i*47-120}deg) scale(1)`,opacity:0}
      ],{duration:1000 + Math.random()*300,easing:'cubic-bezier(.15,.75,.2,1)'});
      flight.onfinish = () => particle.remove();
    }
  }));
})();
