/*
  CAMP BACH — multiplayer config
  Leave these empty for local demo mode (works across tabs on one browser).
  To make room codes work across different phones, create a free Supabase project,
  run supabase-setup.sql, then paste the Project URL + anon/publishable key here.
*/
window.CAMPBACH_CONFIG = {
  supabaseUrl: "https://jxggsmjdkugjmzanqsvo.supabase.co",
  supabaseAnonKey: "sb_publishable_rYNcua5PBCDo039kcuhmqw_BWv4tO6s"
};
