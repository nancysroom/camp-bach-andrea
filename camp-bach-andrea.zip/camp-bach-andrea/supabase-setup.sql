-- CAMP BACH · realtime party game
-- Run this once in Supabase > SQL Editor.
-- This schema is intentionally simple for a private party room-code game.

create extension if not exists pgcrypto;

create table if not exists public.rooms (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  host_player_id uuid,
  status text not null default 'lobby',
  game_state jsonb not null default '{"phase":"lobby"}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.players (
  id uuid primary key default gen_random_uuid(),
  room_id uuid not null references public.rooms(id) on delete cascade,
  name text not null,
  answers jsonb not null default '{}'::jsonb,
  suggestions jsonb not null default '[]'::jsonb,
  ready boolean not null default false,
  score integer not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.votes (
  id uuid primary key default gen_random_uuid(),
  room_id uuid not null references public.rooms(id) on delete cascade,
  round_no integer not null,
  player_id uuid not null references public.players(id) on delete cascade,
  answer text not null,
  response_ms integer not null default 0,
  created_at timestamptz not null default now(),
  unique (room_id, round_no, player_id)
);

create index if not exists players_room_idx on public.players(room_id);
create index if not exists votes_room_idx on public.votes(room_id);

alter table public.rooms enable row level security;
alter table public.players enable row level security;
alter table public.votes enable row level security;

-- Casual event-room policies: anyone with the site + room code can participate.
-- Do not store sensitive information in the game answers.
do $$ begin
  create policy "party read rooms" on public.rooms for select using (true);
exception when duplicate_object then null; end $$;
do $$ begin
  create policy "party create rooms" on public.rooms for insert with check (true);
exception when duplicate_object then null; end $$;
do $$ begin
  create policy "party update rooms" on public.rooms for update using (true) with check (true);
exception when duplicate_object then null; end $$;

do $$ begin
  create policy "party read players" on public.players for select using (true);
exception when duplicate_object then null; end $$;
do $$ begin
  create policy "party create players" on public.players for insert with check (true);
exception when duplicate_object then null; end $$;
do $$ begin
  create policy "party update players" on public.players for update using (true) with check (true);
exception when duplicate_object then null; end $$;

do $$ begin
  create policy "party read votes" on public.votes for select using (true);
exception when duplicate_object then null; end $$;
do $$ begin
  create policy "party create votes" on public.votes for insert with check (true);
exception when duplicate_object then null; end $$;
do $$ begin
  create policy "party update votes" on public.votes for update using (true) with check (true);
exception when duplicate_object then null; end $$;

-- Realtime (run once; if a table is already in the publication, Supabase may say it already exists).
alter publication supabase_realtime add table public.rooms;
alter publication supabase_realtime add table public.players;
alter publication supabase_realtime add table public.votes;
